import sublime
import sublime_plugin


class InsertTabCharCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        settings = sublime.load_settings("Preferences.sublime-settings")
        settings.set("translate_tabs_to_spaces", False)
        sublime.save_settings("Preferences.sublime-settings")
        for insertionPoint in self.view.sel():
            self.view.insert(edit, insertionPoint.begin(), "\t")
        settings.set("translate_tabs_to_spaces", True)
        sublime.save_settings("Preferences.sublime-settings")