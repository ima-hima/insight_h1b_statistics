#! /bin/sh

osascript -e '
    on run parameters
        tell application "iTerm2"
            tell current window
                create tab with default profile
                end tell
            end tell
        end tell
    end run
'