#!/bin/zsh

bbdiff --ignore-spaces $1 $2
