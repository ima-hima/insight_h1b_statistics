#!/bin/zsh

bbdiff --ignore-spaces /Users/eric/Dropbox/Apps/Sublime/User/HTML.sublime-settings /Users/eric/Dropbox/Apps/Sublime/User/insert_tab_char.py
